#ifndef COMM_FUNCS_H
#define COMM_FUNCS_H

#include <cmath>

int gcd (int, int);

bool distinct_vals(int *, int);

int cnt_s_nums(int);

bool is_simple(int);

#endif // COMM_FUNCS_H
